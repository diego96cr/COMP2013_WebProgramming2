//Create an interface for the navbar
import NavBar from "./NavBar";
import { useState } from "react";
import type { ClothingProduct } from "../data/data";
import CheckoutContainer from "./CheckoutContainer";
import ItemContainer from "./ItemContainer";

interface ClothingData {
  // Catalog entries used to initialize state and supply card labels and options.
  data: ClothingProduct[];
}

export interface ItemInfo {
  // Links this state entry to the catalog item independently of array order.
  id: number;
  // Current selected quantity, kept nonnegative by FruitsApp's update function.
  itemQuantity: number;

  quantity: number;
  // Selected unit price, rather than the calculated total.
  price: number;
}

export interface CartItem {
  // A new UUID identifies each cart entry, including repeated adds of one fruit.
  id: string;
  name: string;
  image: string;
  price: number;
  itemQuantity: number;
  quantity: number;
  total: number;
}

export default function ThriftHappensApp({ data }: ClothingData) {
  //////////////////////////////////////////////

  const [itemInfo, setItemInfo] = useState<ItemInfo[]>(() =>
    data.map((item) => ({
      id: item.id,
      itemQuantity: item.itemQuantity,
      price: item.price,
      quantity: item.quantity,
    })),
  );

  // Start with an empty cart. Cart snapshots are independent of productInfo:
  // changing a product's current quantity or price does not edit saved entries.
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // delta is the requested change (+1 or -1 from a card), not an absolute quantity.
  function handleAdjustQuantity(id: number, delta: number) {
    // A functional update uses the latest pending state, so successive clicks
    // build on previous updates even when React batches them.
    setItemInfo((prevData) =>
      // map creates a new array; spread copies only the matching object.
      // Preserve other entries and clamp the new quantity to zero.
      prevData.map((info) =>
        info.id === id
          ? {
              ...info,
              itemQuantity: Math.min(
                info.quantity,
                Math.max(0, info.itemQuantity + delta),
              ),
            }
          : info,
      ),
    );
  }

  // Append a separate entry for every click, rather than merging matching fruits.
  // Functional updates preserve earlier additions when React batches updates.
  function handleAddToCart(cartItem: CartItem) {
    setCartItems((prevCart) => {
      // Spread creates a new array and copies the submitted snapshot without
      // mutating either the previous cart or the object passed by the card.
      return [...prevCart, { ...cartItem }];
    });
  }

  return (
    <div>
      <NavBar />
      <br />
      <ItemContainer
        data={data}
        itemInfo={itemInfo}
        handleAdjustQuantity={handleAdjustQuantity}
        handleAddToCart={handleAddToCart}
      />
      <CheckoutContainer cartData={cartItems} />
    </div>
  );
}
