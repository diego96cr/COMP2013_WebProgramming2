export default function NavBar() {
  return (
    <div>
      <img src="src\assets\images\logo.png" alt="" width="150px" />
    </div>
  );
}
